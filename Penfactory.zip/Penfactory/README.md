# Penfactory Lagerbestand-Management-Tool
Diese Software mit GUI ermöglicht es der Penfactory ihren Lagerbestand zu verwalten.

## Features:
* Manuelles hinzufügen, bearbeiten und entfernen von Artikeln
* Speichert im Lager vorhandene Anzahl einzelner Artikel
* Speichert den Lagerbestand permanent
* Ermöglicht die Suche nach Artikeln durch Name oder Kategorie

