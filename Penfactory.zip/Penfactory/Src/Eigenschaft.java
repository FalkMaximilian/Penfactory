package Src;

public enum Eigenschaft {
	Alle,
	Produktbezeichnung,
	Kategorie,
	Anzahl,
	Gewicht,
	Preis,
	Platznummer;
}
